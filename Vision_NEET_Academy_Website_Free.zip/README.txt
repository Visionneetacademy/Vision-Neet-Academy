VISION NEET ACADEMY WEBSITE
===========================

Free hosting option:
1. Create a free GitHub account.
2. Create a public repository named: yourusername.github.io
3. Upload index.html.
4. Open Settings > Pages.
5. Select Deploy from branch, choose main/root, and Save.
6. Your website will be available at https://yourusername.github.io

Replace photos/logo later if desired. Contact details are already included.
